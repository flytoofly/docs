#1.SQL优化步骤
##1.1了解执行频率
查询服务器中sql的执行情况：

    show [session|global] status
- session 级（当前连接）的统计结果
- global 级（自数据库上次启动至今）的统计结果。
- 如果不写，默认使用参数是“session”。

案例：
mysql> show status like 'Com_%';

+--------------------------+-------+

| Variable_name | Value |

+--------------------------+-------+

| Com_admin_commands | 0 |

| Com_alter_db | 0 |

| Com_alter_event | 0 |

| Com_alter_table | 0 |

| Com_analyze | 0 |

| Com_backup_table | 0 |

| Com_begin | 0 |

| Com_change_db | 1 |

| Com_change_master | 0 |

| Com_check | 0 |

| Com_checksum | 0 |

| Com_commit | 0 |

……

Com_xxx 表示每个 xxx 语句执行的次数，通常比较关心的是以下几个统计参数：

- Com_select：执行 select 操作的次数，一次查询只累加 1。
- Com_insert：执行 INSERT 操作的次数，对于批量插入的 INSERT 操作，只累加一次。
- Com_update：执行 UPDATE 操作的次数。
- Com_delete：执行 DELETE 操作的次数。


上面参数对于所有存储引擎的表操作都会进行累计。下面这几个参数只是针对InnoDB 存储引擎的，累加的算法也略有不同。

- Innodb_rows_read：select 查询返回的行数。
- Innodb_rows_inserted：执行 INSERT 操作插入的行数。
- Innodb_rows_updated：执行 UPDATE 操作更新的行数。
- Innodb_rows_deleted：执行 DELETE 操作删除的行数。

通过以上几个参数，可以很容易地了解当前数据库的应用是以插入更新为主还是以查询
操作为主，以及各种类型的 SQL 大致的执行比例是多少。对于更新操作的计数，是对执行
次数的计数，不论提交还是回滚都会进行累加。

对于事务型的应用，通过 Com_commit 和 Com_rollback 可以了解事务提交和回滚的情况，**对于回滚操作非常频繁的数据库，可能意味着应用编写存在问题**。

此外，以下几个参数便于用户了解数据库的基本情况。

- Connections：试图连接 MySQL 服务器的次数。
- Uptime：服务器工作时间。
- Slow_queries：慢查询的次数

##1.2定位执行效率低的SQL
- 通过**慢查询日志定位**那些执行效率较低的 SQL 语句，用--log-slow-queries[=file_name]选项启动时，mysqld 写一个包含所有执行时间超过 long_query_time 秒的 SQL 语句日志文件。具体可以查看本书第 26 章中日志管理的相关部分。
- 慢查询日志在查询结束以后才纪录，所以在应用反映执行效率出现问题的时候查询慢查询日志并不能定位问题，可以使用**show processlist命令查看当前MySQL在进行的线程，包括线程的状态、是否锁表等，可以实时地查看 SQL 的执行情况，同时对一些锁表操作进行优化**。

##1.3 explain分析低效SQL的执行计划
分析低效SQL的执行信息：

以通过 EXPLAIN 或者 DESC 命令获取 MySQL如何执行 SELECT 语句的信息，包括在 SELECT 语句执行过程中表如何连接和连接的顺序，

案例：

    mysql> explain select sum(moneys) from sales a,company b where a.company_id = b.id and a.year 
    = 2006\G;
    ************* 1. row ***********
     id: 1
     select_type: SIMPLE
     table: a
     type: ALL
    possible_keys: NULL
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    ************* 2. row ***********
     id: 1
     select_type: SIMPLE
     table: b
     type: ref
    possible_keys: ind_company_id
     key: ind_company_id
     key_len: 5
     ref: sakila.a.company_id
     rows: 1
     Extra: Using where; Using index
    2 rows in set (0.00 sec)
每个列的简单解释如下：

- **select_type**：表示 SELECT 的类型，常见的取值有 **SIMPLE**（简单表，即不使用表连接或者子查询）、**PRIMARY**（主查询，即外层的查询）、**UNION**（UNION 中的第二个或者后面的查询语句）、**SUBQUERY**（子查询中的第一个 SELECT）等。
- **table**：输出结果集的表。
- **type**：表示表的连接类型，性能由好到差的连接类型为 **system**（表中仅有一行，即常量表）、**const**（单表中最多有一个匹配行，例如 primary key 或者 unique index）、**eq_ref**（对于前面的每一行，在此表中只查询一条记录，简单来说，就是多表连接中使用primary key或者unique index）、**ref**（与eq_ref类似，区别在于不是使用primary key 或者 unique index，而是使用普通的索引）、**ref_or_null**（与 ref 类似，区别在于条件中包含对 NULL 的查询）、**index_merge**(索引合并优化)、**unique_subquery**（in的后面是一个查询主键字段的子查询）、**index_subquery**（与 unique_subquery 类似，区别在于 in 的后面是查询非唯一索引字段的子查询）， **range** （单表中的范围查询），**index**（对于前面的每一行，都通过查询索引来得到数据）、**all**（对于前面的每一行，都通过全表扫描来得到数据）。
- **possible_keys**：表示查询时，可能使用的索引。
- **key**：表示实际使用的索引。
- **key_len**：索引字段的长度。
- **rows**：扫描行的数量。
- **Extra**：执行情况的说明和描述。

##1.4确定问题并制定优化措施
经分析是对a表的权标扫描导致效率的不理想，故对a表year字段创建索引

创建索引：

    mysql> create index ind_sales2_year on sales2(year);

    mysql> explain select sum(moneys) from sales2 a,company2 b where a.company_id = b.id and 
    a.year = 2006\G;
    *************** 1. row ************
     id: 1
     select_type: SIMPLE
     table: a
     type: ref
    possible_keys: ind_sales2_year
     key: ind_sales2_year
     key_len: 2
     ref: const
     rows: 1
     Extra: Using where
    **************** 2. row ************
     id: 1
     select_type: SIMPLE
     table: b
     type: ref
    possible_keys: ind_company2_id
     key: ind_company2_id
     key_len: 5
     ref: sakila.a.company_id
     rows: 1
     Extra: Using where; Using index
    2 rows in set (0.00 sec)

对比发现： 建立索引后对a表需要扫描的行数明显减少（从1000行减少到1行），可见索引的使用可以大大提高数据库的访问速度


#2.索引问题
索引是数据库优化中最常用也是最重要的手段之一，通过索引通常可以帮助用户解决大多数的 SQL 性能问题

##2.1索引的存储分类
- **MyISAM** 存储引擎的表的数据和索引是**自动分开存储的**，各自是独立的一个文件；
- **InnoDB** 存储引擎的表的数据和索引是存储在**同一个表空间里面**，但可以有多个文件组成。

MySQL 中索引的存储类型目前只有两种（BTREE 和 HASH），具体和表的存储引擎相关：

**MyISAM** 和 **InnoDB** 存储引擎都**只支持 BTREE 索引**；

**MEMORY**/**HEAP** 存储引擎可以**支持 HASH和 BTREE 索引**。

MySQL 目前不支持函数索引，但是能对列的前面某一部分进索引，这个特性可以大大缩小索引文件的大小，用户在设计表结构的时候也可以对文本列根据此特性进行灵活设计。创建前缀索引的例子：
    mysql> create index ind_company2_name on company2(name(4));

##2.2索引的使用
使用索引是提高 SELECT 操作性能的最佳途径。

查询要使用索引最主要的条件是查询条件中需要使用索引关键字，如果是**多列索引**，那么只有查询条件使用了多列关键字**最左边的前缀时，才可以使用索引**，否则将不能使用索引。

###2.2.1使用索引
**a.复合索引**

创建复合索引

    mysql> create index ind_sales2_companyid_moneys on sales2(company_id,moneys)

表查询

    mysql> explain select * from sales2 where company_id = 2006\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: sales2
     type: ref
     possible_keys: ind_sales2_companyid_moneys
     key: ind_sales2_companyid_moneys
     key_len: 5
     ref: const
     rows: 1
     Extra: Using where
    1 row in set (0.00 sec)

发现 where 条件中不是用的 company_id 与 moneys 的组合条件，索引仍然能用到，这就是**索引的前缀特性**。但是如果只按 moneys 条件查询表，那么索引就不会被用到，

非前缀查询：

    mysql> explain select * from sales2 where moneys = 1\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: sales2
     type: ALL
    possible_keys: NULL
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    1 row in set (0.00 sec)

**b.like查询**

对于使用 like 的查询，后面如果是常量并且只有％号不在第一个字符，索引才可能会
被使用，来看下面两个执行计划：

    mysql> explain select * from company2 where name like '%3'\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: ALL
     possible_keys: NULL
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    1 row in set (0.00 sec)
    mysql> explain select * from company2 where name like '3%'\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: range
     possible_keys: ind_company2_name
     key: ind_company2_name
     key_len: 11
     ref: NULL
     rows: 103
     Extra: Using where
    1 row in set (0.00 sec)

发现第一个例子没有使用索引，而第二例子就能够使用索引，区别就在于“%”的位置不同，**前者把“%”放到第一位就不能用到索引，而后者没有放到第一位就使用了索引**。

**c.大文本搜索**

如果对大的文本进行搜索，使用全文索引而不用使用 like ‘%…%’。

**d.列名是索引**

如果列名是索引，使用 column_name is null 将使用索引。如下例中查询 name 为 null的记录就用到了索引：
    
    mysql> explain select * from company2 where name is null\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: ref
    possible_keys: ind_company2_name
     key: ind_company2_name
     key_len: 11
     ref: const
     rows: 1
     Extra: Using where
    1 row in set (0.00 sec)


###2.2.2存在索引但不使用索引

场景：

1.如果 MySQL 估计使用索引比全表扫描更慢，则不使用索引。例如如果列key_part1 均匀分布在 1 和 100 之间，下列查询中使用索引就不是很好：

    SELECT * FROM table_name where key_part1 > 1 and key_part1 < 90;

2.如果使用 MEMORY/HEAP 表并且 where 条件中不使用“=”进行索引列，那么不会用到索引。**heap 表只有在“=”的条件下才会使用索引。**

3.**用 or 分割开的条件，如果 or 前的条件中的列有索引，而后面的列中没有索引，那么涉及到的索引都不会被用到**

    mysql> explain select * from sales where year = 2001 or country = 'China'\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: sales
     type: ALL
     possible_keys: ind_sales_year
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 12
     Extra: Using where
    1 row in set (0.00 sec)

可见虽然在year这个列上存在索引ind_sales_year，但是这个SQL语句并没有用到这个索引，
**原因就是 or 中有一个条件中的列没有索引**。

**4.如果不是索引列的第一部分**

例：
    
    mysql> explain select * from sales2 where moneys = 1\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: sales2
     type: ALL
     possible_keys: NULL
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    1 row in set (0.00 sec)
可见虽然在 money 上面建有复合索引，但是由于 money **不是索引的第一列，那么在查询中,这个索引也不会被 MySQL 采用**

**5.如果 like 是以％开始**

例：

    mysql> explain select * from company2 where name like '%3'\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: ALL
     possible_keys: NULL
     key: NULL
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    1 row in set (0.00 sec)

可见虽然在 name 上建有索引，但**是由于 where 条件中 like 的值的“%”在第一位了，那么
MySQL 也不会采用这个索引**。

**6.列类型是字符串**

如果列类型是字符串，那么一定记得在 where 条件中**把字符常量值用引号引起来，**否则的话即便这个列上有索引，MySQL 也不会用到的，因为，MySQL 默认把输入的常量值进行转换以后才进行检索。
    
    mysql> explain select * from company2 where name = 294\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: ALL
    possible_keys: ind_company2_name
     key: NULL 
     key_len: NULL
     ref: NULL
     rows: 1000
     Extra: Using where
    1 row in set (0.00 sec)

    mysql> explain select * from company2 where name = '294'\G;
    *************************** 1. row ***************************
     id: 1
     select_type: SIMPLE
     table: company2
     type: ref
    possible_keys: ind_company2_name
     key: ind_company2_name 
     key_len: 23
     ref: const
     rows: 1
     Extra: Using where
    1 row in set (0.00 sec)

中可以看到，第一个 SQL 语句中把一个数值型常量赋值给了一个字符型的列name，那么虽然在 name 列上有索引，但是也没有用到；而第二个 SQL 语句就可以正确使用索引

###2.3查看索引使用情况

**Handler_read_key** 的值将很高，这个值代表了一个行被索引值读的次数，很低的值表明增加索引得到的性能改善不高，因为索引并不经常使用。

**Handler_read_rnd_next** 的值高则意味着查询运行低效，并且应该建立索引补救。这个值的含义是在数据文件中读下一行的请求数。如果正进行大量的表扫描，Handler_read_rnd_next 的值较高，则通常说明表索引不正确或写入的查询没有利用索引

    mysql> show status like 'Handler_read%';
    +-----------------------+-------+
    | Variable_name | Value |
    +-----------------------+-------+
    | Handler_read_first | 0 |
    | Handler_read_key | 5 |
    | Handler_read_next | 0 |
    | Handler_read_prev | 0 |
    | Handler_read_rnd | 0 |
    | Handler_read_rnd_next | 2055 |
    +-----------------------+-------+
    6 rows in set (0.00 sec)


#3.实用优化方法
##3.1定期分析表和检查表

分析表的语法如下：

    ANALYZE [LOCAL | NO_WRITE_TO_BINLOG] TABLE tbl_name [, tbl_name] ... 

本语句用于分析和存储表的**关键字分布**，分析的结果**将可以使得系统得到准确的统计信息，使得 SQL 能够生成正确的执行计划**。如果用户感觉实际执行计划并不是预期的执行计划，执行一次分析表可能会解决问题。在分析期间，使用一个读取锁定对表进行锁定。这对于 MyISAM, BDB 和 InnoDB 表有作用。对于 MyISAM 表，本语句与使用 myisamchk -a 相当。

表分析：
    
    mysql> analyze table sales;
    +--------------+---------+----------+----------+
    | Table | Op | Msg_type | Msg_text |
    +--------------+---------+----------+----------+
    213
    Linux公社 www.linuxidc.com
    | sakila.sales | analyze | status | OK |
    +--------------+---------+----------+----------+
    1 row in set (0.00 sec)

检查表的语法如下：
    
    CHECK TABLE tbl_name [, tbl_name] ... [option] ... option = {QUICK | FAST | MEDIUM | EXTENDED | CHANGED} 

**检查表的作用是检查一个或多个表是否有错误**。CHECK TABLE对MyISAM 和InnoDB表有作用。
对于 MyISAM 表，关键字统计数据被更新，例如：
    mysql> check table sales;
    +--------------+-------+----------+----------+
    | Table | Op | Msg_type | Msg_text |
    +--------------+-------+----------+----------+
    | sakila.sales | check | status | OK |
    +--------------+-------+----------+----------+
    1 row in set (0.00 sec)

**CHECK TABLE 也可以检查视图是否有错误**，比如在视图定义中被引用的表已不存在，例如:

（1）首先我们创建一个视图。

    mysql> create view sales_view3 as select * from sales3;
    Query OK, 0 rows affected (0.00 sec)

（2）然后 CHECK 一下该视图，发现没有问题。

    mysql> check table sales_view3;
    +--------------------+-------+----------+----------+
    | Table | Op | Msg_type | Msg_text |
    +--------------------+-------+----------+----------+
    | sakila.sales_view3 | check | status | OK |
    +--------------------+-------+----------+----------+
    1 row in set (0.00 sec)

（3）现在删除掉视图依赖的表。

    mysql> drop table sales3;
    Query OK, 0 rows affected (0.00 sec)

（4）再来 CHECK 一下刚才的视图，发现报错了。

    mysql> check table sales_view3\G;
    *************************** 1. row ***************************
     Table: sakila.sales_view3
     Op: check
    Msg_type: error
    Msg_text: View 'sakila.sales_view3' references invalid table(s) or column(s) or function(s) 
    or definer/invoker of view lack rights to use them
    1 row in set (0.00 sec)

##3.2定期优化表
优化表的语法如下：

    OPTIMIZE [LOCAL | NO_WRITE_TO_BINLOG] TABLE tbl_name [, tbl_name] ...

如果已经删除了表的一大部分，或者如果已经对含有可变长度行的表（含有 VARCHAR、BLOB 或 TEXT 列的表）进行了很多更改，则应使用 OPTIMIZE TABLE 命令来进行表优化。这个命令可以**将表中的空间碎片进行合并，并且可以消除由于删除或者更新造成的空间浪费**，但OPTIMIZE TABLE 命令只对 MyISAM、BDB 和 InnoDB 表起作用。

以下例子显示了优化表 sales 的过程：

    mysql> optimize table sales;
    +--------------+----------+----------+----------+
    | Table | Op | Msg_type | Msg_text |
    +--------------+----------+----------+----------+
    | sakila.sales | optimize | status | OK |
    +--------------+----------+----------+----------+
    1 row in set (0.00 sec)

注意：ANALYZE、CHECK、OPTIMIZE 执行期间将对表进行锁定，因此一定注意要在数据库不
繁忙的时候执行相关的操作

#4.常用SQL优化
##4.1 大批量插入数据
###4.1.1 MyISAM
对于 MyISAM 存储引擎的表，可以通过以下方式快速的导入大量的数据。

    ALTER TABLE tbl_name DISABLE KEYS;
    loading the data
    ALTER TABLE tbl_name ENABLE KEYS;

###4.1.2 InnoDB
提高InnoDB表的导入效率：

1. 因为 InnoDB 类型的表是按照主键的顺序保存的，所以**将导入的数据按照主键的顺序排列**，可以有效地提高导入数据的效率。
2. 在导入数据前执行 SET UNIQUE_CHECKS=0，**关闭唯一性校验**，在导入结束后执行 SET UNIQUE_CHECKS=1，恢复唯一性校验，可以提高导入的效率。
3. 如果应用**使用自动提交**的方式，建议在导入前执行 SET AUTOCOMMIT=0，关闭自动提交，导入结束后再执行 SET AUTOCOMMIT=1，打开自动提交，也可以提高导入的效率。

##4.2 优化insert语句
当进行数据 INSERT 的时候，可以考虑采用以下几种优化方式。

- 如果同时从同一客户插入很多行，**尽量使用多个值表的 INSERT 语句**，这种方式将大大缩减客户端与数据库之间的连接、关闭等消耗，使得效率比分开执行的单个 INSERT 语句快(在一些情况中几倍)。下面是一次插入多值的一个例子：

    insert into test values(1,2),(1,3),(1,4)…

- 如果从不同客户插入很多行，**能通过使用 INSERT DELAYED 语句得到更高的速度**。DELAYED 的含义是让 INSERT 语句马上执行，其实数据都被放在内存的队列中，并没有真正写入磁盘，这比每条语句分别插入要快的多；LOW_PRIORITY 刚好相反，在所有其他用户对表的读写完后才进行插入；
- **将索引文件和数据文件分在不同的磁盘上存放**（利用建表中的选项）；
- 如果进行批量插入，可以增加 bulk_insert_buffer_size 变量值的方法来提高速度，但是，这只能对 MyISAM 表使用；
- 当从一个文本**文件装载**一个表时，使用 LOAD DATA INFILE。这通常比使用很多 INSERT 语句快 20 倍。

##4.3 优化groupby语句
**默认情况**下，MySQL 对所有 GROUP BY col1，col2....的字段**进行排序**。这与在查询中指定
ORDER BY col1，col2...类似。因此，如果显式包括一个包含相同的列的 ORDER BY 子句，则
对 MySQL 的实际执行性能没有什么影响。

如果查询包括 GROUP BY 但用户想要避免排序结果的消耗，则可以**指定 ORDER BY NULL禁止排序**

##4.4 优化order by语句
在某些情况中，MySQL 可以使用一个索引来满足 ORDER BY 子句，而不需要额外的排序。WHERE 条件和 ORDER BY 使用相同的索引，并且 ORDER BY 的顺序和索引顺序相同，并且ORDER BY 的字段都是升序或者都是降序。

##4.5 优化嵌套查询
使用子查询可以一次性地完成很多逻辑上需要多个步骤才能完成的 SQL 操作，同时也可以避免事务或者表锁死，并且写起来也很容易。但是，**有些情况下，子查询可以被更有效率的连接（JOIN）替代**。在有建立索引的情况下join更快。

##4.6 优化OR条件
对于含有 OR 的查询子句，**如果要利用索引，则 OR 之间的每个条件列都必须用到索引**；如果没有索引，则应该考虑增加索引。

在处理含有 OR字句的查询时，实际是对 OR 的各个字段分别查询后的结果进行了 UNION。

##4.7 使用SQL提示
常见SQL提示：

1.USE INDEX

在查询语句中表名的后面，添加 USE INDEX 来提供希望 MySQL 去参考的索引列表，就可以让 MySQL 不再考虑其他可用的索引。

    mysql> explain select * from sales2 use index (ind_sales2_id) where id = 3\G;

2．IGNORE INDEX

如果用户只是单纯地想让 MySQL 忽略一个或者多个索引，则可以使用 IGNORE INDEX 作为 HINT。同样是上面的例子，这次来看一下查询过程忽略索引 ind_sales2_id 的情况：

    mysql> explain select * from sales2 ignore index (ind_sales2_id) where id = 3\G;

3．FORCE INDEX

为强制 MySQL 使用一个特定的索引，可在查询中使用 FORCE INDEX 作为 HINT。例如，
当不强制使用索引的时候，因为 id 的值都是大于 0 的，因此 MySQL 会默认进行全表扫描，
而不使用索引，如下所示：

    mysql> explain select * from sales2 where id > 0 \G;

但是，当使用 FORCE INDEX 进行提示时，即便使用索引的效率不是最高，MySQL 还是选择使用了索引，这是 MySQL 留给用户的一个自行选择执行计划的权力。加入 FORCE INDEX 提示后再次执行上面的 SQL：

    mysql> explain select * from sales2 force index (ind_sales2_id) where id > 0 
    \G;
