#简介
QL Mode 常用来解决下面几类问题：

- 通过设置 SQL Mode，可以完成不同严格程度的数据校验，有效地保障数据准确性。
- 通过设置 SQL Mode 为 ANSI 模式，来保证大多数 SQL 符合标准的 SQL 语法,这样应用在不同数据库之间进行迁移时，则不需要对业务 SQL 进行较大的修改。
- 在不同数据库之间进行数据迁移之前，通过设置 SQL Mode 可以使 MySQL 上的数据更方便地迁移到目标数据库中。

#场景SQL Mode
- ANSI：等同于 REAL_AS_FLOAT、PIPES_AS_CONCAT、ANSI_QUOTES、IGNORE_SPACE 和 ANSI组合模式，这种模式使语法和行为更符合标准的 SQL
- STRICT_TRANS_TABLES：适用于事务表和非事务表，它是严格模式，不允许非法日期，也不允许超过字段长度的值插入字段中，对于插入不正确的值给出错误而不是警告
- TRADITIONAL 模式：等同于 STRICT_TRANS_TABLES、STRICT_ALL_TABLES、NO_ZERO_IN_DATE、NO_ZERO_DATE、ERROR_FOR_DIVISION_BY_ZERO、TRADITIONAL和 NO_AUTO_CREATE_USER 组合模式，所以它也是严格模式，对于插入不正确的值是给出错误而不是警告。可以应用在事务表和非事务表，用在事务表时，只要出现错误就会立即回滚

#数据库迁移
如果 MySQL 与其他异构数据库之间有数据迁移的需求的话，那么 MySQL 中提供的的数据库组合模式则会对数据迁移过程会有所帮助。
