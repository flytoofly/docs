#1.以root用户登录：

    mysql -u root -p

#2.创建数据库

    create database testname;

#3.删除数据库

    drop database testname;

#4.选择数据库

    use testname;

#5.创建表

    create table table_name(
		id  int not null auto_increment,
		title varchar(100) not null,
		submission_date date,
		PRIMARY KEY (id)
	)ENGINE=InnoDB DEFAULT CHARSET=utf8;

注意：MySQL命令终止符为分号 ;

#6.删除表

    DROP TABLE table_name;

#7.查看所有表

    show tables;

#查看表结构

    DESC table_name;

#8.插入表数据

    INSERT INTO table_name(field1, field2, ...) VALUES (value1,value2, ...);

#查看创建表的SQL语句

    SHOW CREATE TABLES table_name;


#9.查询表中数据

    SELECT column_name1, column_name2 FROM table_name [WHERE CLAUSE] [LIMIT M] [OFFSET N];

#10.更新表中数据

    UPDATE table_name SET field1= new_value, field2=new_value2 [WHERE CLAUSE];

#11.删除表中数据

    DELETE FROM table_name [WHERE CLAUSE];

#12.表新增列

    ALTER TABLE table_name ADD COLUMN birth NOT NULL;

#13.修改列名

    ALTER TABLE table_name CHANGE COLUMN birth birthday VARCHAR(20);

#14.删除列名

    ALTER TABLE table_name DROP CLOMN birthday；

# 修改定义

    ALTER TABLE table_name MODIFY column_name new_data_type;

#15.插入或替换

	REPLACE INTO students (id, class_id, name) VALUES (1, 1, '小明');
注：【插入或替换】插入一条新记录（INSERT），但如果记录已经存在，就先删除原记录，再插入新记录

#16.插入或更新

	INSERT INTO students (id, class_id, name) VALUES (1, 1, '小明') ON DUPLICATE KEY UPDATE name='小宏';
注：若id=1的记录不存在，INSERT语句将插入新记录，否则，当前id=1的记录将被更新，更新的字段由UPDATE指定

#17.插入或忽略

    INSERT IGNORE INTO students (id, class_id, name) VALUES (1, 1, '小明');
注：若id=1的记录不存在，INSERT语句将插入新记录，否则，不执行任何操作。

#18.表快照/复制
    CREATE TABLE students_of_class1 SELECT * FROM students WHERE class_id=1;
表进行快照，即复制一份当前表的数据到一个新表

#19.从其他表中选择数据并插入

    INSERT INTO statistics (class_id, average) SELECT class_id, AVG(score) FROM students GROUP BY class_id;
确保INSERT语句的列和SELECT语句的列能一一对应，就可以在statistics表中直接保存查询的结果：

#20.指定索引

    SELECT * FROM students FORCE INDEX (idx_class_id) WHERE class_id = 1 ORDER BY id DESC;
使用FORCE INDEX强制指定索引的前提是索引idx_class_id必须存在。在查询的时候，数据库系统会自动分析查询语句，并选择一个最合适的索引。因数据库系统的查询优化器并不一定总是能使用最优索引。


#21.LIKE 子句

    SELECT field1, field2 FROM table_name WHERE field LIKE "java%";

注：

- %：表示任意 0 个或多个字符。可匹配任意类型和长度的字符，有些情况下若是中文，请使用两个百分号（%%）表示。

- `_`：表示任意单个字符。匹配单个任意字符，它常用来限制表达式的字符长度语句。

- []：表示括号内所列字符中的一个（类似正则表达式）。指定一个字符、字符串或范围，要求所匹配对象为它们中的任一个。

- [^] ：表示不在括号所列之内的单个字符。其取值和 [] 相同，但它要求所匹配对象为指定字符以外的任一个字符。

- 查询内容包含通配符时,由于通配符的缘故，导致我们查询特殊字符 “%”、“_”、“[” 的语句无法正常实现，而把特殊字符用 “[ ]” 括起便可正常查询。

#22. UNION联合

    SELECT field1,field2 FROM table_name1 UNION [ALL | DISTINCT] SELECT field1, field2 FROM table_name2;
注：

- DISTINCT: 可选，删除结果集中重复的数据。默认情况下 UNION 操作符已经删除了重复数据。

- ALL: 可选，返回所有结果集，包含重复数据。

#23.ORDER排序

    SELECT field1, field2 FROM table_name1, table_name2 ORDER BY field1 [ASC|DESC], [field2] [ASC|DESC];

注： ASC 或 DESC 关键字来设置查询结果是按升序或降序排列， 默认ASC

#24.GROUP BY分组

    SELECT column_name1, function(column_name) FROM table_name WHERE conditon GROUP BY column_name;
注：COUNT, SUM, AVG,等函数

#25.WITH ROLLUP

    SELECT name, SUM(signin) as signin_count FROM  employee_tbl GROUP BY name WITH ROLLUP;
注：WITH ROLLUP 可以实现在分组统计数据基础上再进行相同的统计（SUM,AVG,COUNT…）

使用 coalesce 来设置一个可以取代 NUll 的名称，coalesce 语法：select coalesce(a,b,c);

重命名汇总数据的标签名称：

    SELECT coalesce(name, '总数'), SUM(signin) as signin_count FROM  employee_tbl GROUP BY name WITH ROLLUP;

#26.NULL值处理

- IS NULL: 当列的值是 NULL,此运算符返回 true。
- IS NOT NULL: 当列的值不为 NULL, 运算符返回 true。
- <=>: 比较操作符（不同于 = 运算符），当比较的的两个值相等或者都为 NULL 时返回 true。

关于 NULL 的条件比较运算是比较特殊的。你不能使用 = NULL 或 != NULL 在列中查找 NULL 值 。

在 MySQL 中，NULL 值与任何其它值的比较（即使是 NULL）永远返回 NULL，即 NULL = NULL 返回 NULL 。

MySQL 中处理 NULL 使用 IS NULL 和 IS NOT NULL 运算符。

#27.正则表达式

使用 LIKE expr ， expr：正则表达式

#28.事务控制

##事务控制语句

- BEGIN 或 START TRANSACTION 显式地开启一个事务；

- COMMIT 也可以使用 COMMIT WORK，不过二者是等价的。COMMIT 会提交事务，并使已对数据库进行的所有修改成为永久性的；

- ROLLBACK 也可以使用 ROLLBACK WORK，不过二者是等价的。回滚会结束用户的事务，并撤销正在进行的所有未提交的修改；

- SAVEPOINT identifier，SAVEPOINT 允许在事务中创建一个保存点，一个事务中可以有多个 SAVEPOINT；

- RELEASE SAVEPOINT identifier 删除一个事务的保存点，当没有指定的保存点时，执行该语句会抛出一个异常；

- ROLLBACK TO identifier 把事务回滚到标记点；

- SET TRANSACTION 用来设置事务的隔离级别。InnoDB 存储引擎提供事务的隔离级别有READ UNCOMMITTED、READ COMMITTED、REPEATABLE READ 和 SERIALIZABLE。

##MYSQL 事务处理主要有两种方法：

- 1、用 BEGIN, ROLLBACK, COMMIT来实现

    BEGIN 开始一个事务

    ROLLBACK 事务回滚

    COMMIT 事务确认

- 2、直接用 SET 来改变 MySQL 的自动提交模式:

    SET AUTOCOMMIT=0 禁止自动提交
    
    SET AUTOCOMMIT=1 开启自动提交

#29.ALTER 修改表结构

##修改表结构

添加新列：

    ALTER TABLE table_name ADD column_name data_type;

修改列定义：

    ALTER TABLE table_name MODIFY column_name new_data_type;

修改列名称：

    ALTER TABLE table_name CHANGE old_column_name new_column_name data_type;

删除列：

    ALTER TABLE table_name DROP column_name;

##添加约束

添加主键：

    ALTER TABLE table_name ADD PRIMARY KEY (column_name);

添加外键：

    ALTER TABLE table_name ADD FOREIGN KEY (column_name) REFERENCES referenced_table(ref_column_name);

添加唯一约束：

    ALTER TABLE table_name ADD CONSTRAINT constraint_name UNIQUE (column_name);

##创建索引

创建普通索引：

    ALTER TABLE table_name ADD INDEX index_name (column1 [ASC|DESC], column2 [ASC|DESC], ...);

创建唯一索引：


    ALTER TABLE table_name ADD UNIQUE INDEX index_name (column1 [ASC|DESC], column2 [ASC|DESC], ...);

删除索引：

    ALTER TABLE table_name DROP INDEX index_name;

##重命名表：

    ALTER TABLE old_table_name RENAME TO new_table_name;

##修改表存储引擎

    ALTER TABLE table_name ENGINE = new_storage_engine;

#30.索引

索引是一种数据结构，用于加快数据库查询的速度和性能。

##索引分单列索引和组合索引：

    单列索引，即一个索引只包含单个列，一个表可以有多个单列索引。

    组合索引，即一个索引包含多个列。

创建索引时，确保该索引是应用在 SQL 查询语句的条件(一般作为 WHERE 子句的条件)。

实际上，**索引也是一张表，该表保存了主键与索引字段，并指向实体表的记录**。

索引虽然能够提高查询性能，但也需要注意以下几点：
    
    1.索引需要占用额外的**存储空间**。
    
    2.对表进行插入、更新和删除操作时，**索引需要维护，可能会影响性能**。
    
    3.过多或不合理的索引**可能会导致性能下降**，因此需要谨慎选择和规划索引。

##创建普通索引：

    CREATE TABLE table_name (
      column1 data_type,
      column2 data_type,
      ...,
      INDEX index_name (column1 [ASC|DESC], column2 [ASC|DESC], ...)
    );

    CREATE TABLE students (
      id INT PRIMARY KEY,
      name VARCHAR(50),
      age INT,
      INDEX idx_age (age)
    );

##创建唯一索引：

    CREATE TABLE table_name (
      column1 data_type,
      column2 data_type,
      ...,
      CONSTRAINT index_name UNIQUE (column1 [ASC|DESC], column2 [ASC|DESC], ...)
    );

    CREATE TABLE employees (
      id INT PRIMARY KEY,
      name VARCHAR(50),
      email VARCHAR(100) UNIQUE
    );

注：email 列被定义为唯一索引，因为在它的后面加上了 UNIQUE 关键字。注意，使用 UNIQUE 关键字后，索引名称将自动生成，你也可以根据需要指定索引名称

#31.临时表

临时表只在当前连接可见，当关闭连接时，Mysql会自动删除表并释放所有空间。

    CREATE TEMPORARY TABLE table_name (
      product_name VARCHAR(50) NOT NULL，
      total_sales DECIMAL(12,2) NOT NULL DEFAULT 0.00，
      avg_unit_price DECIMAL(7,2) NOT NULL DEFAULT 0.00，
      total_units_sold INT UNSIGNED NOT NULL DEFAULT 0，
    );